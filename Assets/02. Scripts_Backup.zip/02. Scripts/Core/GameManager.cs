using System;
using System.Collections;
using System.Collections.Generic;
using DialogueSystem;
using UnityEngine;
using UnityEngine.Playables;
public class GameManager : Singleton<GameManager>
{
    [Header("챕터별 이동 위치")]
    [SerializeField] Vector3 mainStreetMap;
    [SerializeField] Vector3 chapter1Map;
    [SerializeField] Vector3 chapter2Map;
    [SerializeField] Vector3 chapter3Map;
    public GameData gameData = new GameData();
    // 현재 대화 묶음 안에서 진행 중인 줄 인덱스
    public int currentLineIdx = 0;
    // Raycast에서 오브젝트가 사라져도 대화를 유지하기 위한 필드
    private ObjectData currentDialogueObject;
    // 대화 이벤트 또는 대사 출력 준비가 진행 중인지 확인
    private bool isProcessingDialogueLine;

    // nextLineIdx가 아닌 실제 마지막으로 표시한 대사의 ID와 줄 번호
    private int lastDisplayedDialogueId = -1;
    private int lastDisplayedLineIndex = -1;
    //monologue params
    private bool isMonologue;
    private int currentMonologueId;
    private int currentMonologueLineIdx;
    //callback params
    private Action onMonologueFinished, onDialogueFinished;
    private readonly HashSet<PlayableDirector> playedDirector = new HashSet<PlayableDirector>();
    public void CutSceneAction(PlayableDirector director)
    {
        if (director == null)
            return;
        if (!playedDirector.Add(director))
            return;
        director.Play();
        gameData.isRunningCutScene = true;
    }
    public void TriggerAction()
    {
        if (isProcessingDialogueLine ||
            FadeManager.Instance.fadeData.isFading)
        {
            return;
        }
        if (gameData.triggerObjectData == null)
            return;
        gameData.isTrigger = true;
        currentDialogueObject =
            gameData.triggerObjectData;
        Talk(currentDialogueObject);
    }
    public void Action()
    {
        if (FadeManager.Instance.fadeData.isFading ||
            isProcessingDialogueLine)
        {
            return;
        }
        if (isMonologue)
        {
            if (TextAnim.Instance.isAnim)
            {
                TextAnim.Instance.SetText("");
                return;
            }
            NextMonologueLine();
            return;
        }
        // 이미 대화 중이면 Raycast 결과와 관계없이 기존 대화 진행
        if (gameData.isAction &&
            currentDialogueObject != null)
        {
            Talk(currentDialogueObject);
            return;
        }
        if (gameData.scanObject == null)
        {
            return;
        }
        ObjectData objData =
            gameData.scanObject.GetComponent<ObjectData>();
        if (objData == null)
        {
            Debug.LogWarning(
                "상호작용 오브젝트에 ObjectData가 없습니다."
            );
            return;
        }
        Debug.Log(
    $"상호작용 대상: {objData.name}, " +
    $"현재 대화 ID: {objData.GetCurrentDialogueId()}"
);
        currentDialogueObject = objData;
        Talk(currentDialogueObject);
    }
    public void Talk(ObjectData objData)
    {
        if (isProcessingDialogueLine)
            return;
        if (objData == null)
        {
            EndDialogue(null);
            return;
        }
        // 타이핑 애니메이션 진행 중이면 문장 전체 출력
        if (TextAnim.Instance.isAnim)
        {
            TextAnim.Instance.SetText("");
            return;
        }
        int lineIndex =
            currentLineIdx;
        DialogueLine? lineNullable =
            DialogueManager.Instance.GetLine(
                objData,
                lineIndex
            );
        if (!lineNullable.HasValue)
        {
            EndDialogue(objData);
            return;
        }
        DialogueLine line =
            lineNullable.Value;
        string nameData =
            DialogueManager.Instance.GetName(
                objData,
                lineIndex
            );
        StartCoroutine(
            ProcessDialogueLine(
                objData,
                line,
                nameData,
                lineIndex
            )
        );
    }
    private IEnumerator ProcessDialogueLine(ObjectData objData, DialogueLine line, string nameData, int lineIndex)
    {
        isProcessingDialogueLine = true;
        int dialogueId =
            objData.GetCurrentDialogueId();
        // 현재 대사를 출력하기 전에 등록된 이벤트 실행
        if (DialogueEventManager.Instance != null)
        {
            yield return StartCoroutine(
                DialogueEventManager.Instance.ExecuteEvent(
                    dialogueId,
                    lineIndex,
                    DialogueEventTiming.BeforeLine
                )
            );
        }
        else
        {
            Debug.LogWarning(
                "DialogueEventManager.Instance가 존재하지 않습니다."
            );
        }
        // 이벤트 실행 도중 대화가 종료되었는지 확인
        if (currentDialogueObject == null)
        {
            isProcessingDialogueLine = false;
            yield break;
        }
        gameData.isAction = true;
        UIManager.Instance.SetDialogueBoxActive(true);
        UIManager.Instance.UpdateDialogueUI(
            nameData,
            line
        );
        lastDisplayedDialogueId = dialogueId;
        lastDisplayedLineIndex = lineIndex;

        if (line.hasChoices)
        {
            ShowDialogueChoices(
                objData,
                line
            );
        }
        else
        {
            currentLineIdx =
                line.nextLineIdx;
        }
        isProcessingDialogueLine = false;
    }
    private void ShowDialogueChoices(ObjectData objData, DialogueLine line)
    {
        UIManager.Instance.ShowChoices(
            line,
            (choiceIndex, nextIdx) =>
            {
                ExecuteChoiceEvent(line.choices[choiceIndex].eventId);
                Debug.Log(
    $"선택지 실행 후: {objData.name}, " +
    $"현재 대화 ID: {objData.GetCurrentDialogueId()}"
);
                UIManager.Instance.HideChoices();
                int dialogueId =
                    objData.GetCurrentDialogueId();
                // Dialogue ID 0: 저장 책상
                if (dialogueId == 0 &&
                    choiceIndex == 0)
                {
                    SaveLoadManager.Instance.SaveGame();
                }
                currentLineIdx = nextIdx;
                StartCoroutine(
                    TalkNextFrame(objData)
                );
            }
        );
    }
    private void ExecuteChoiceEvent(int eventId)
    {
        switch (eventId)
        {
            case 102:
                Chapter1Manager.Instance.SetHomeTime(2);
                break;
            case 103:
                Chapter1Manager.Instance.SetHomeTime(3);
                break;
            case 104:
                Chapter1Manager.Instance.SetHomeTime(4);
                break;
            case 105:
                Chapter1Manager.Instance.SetHomeTime(5);
                break;
            case 106:
                Chapter1Manager.Instance.SetHomeTime(6);
                break;
            case 107:
                Chapter1Manager.Instance.isOpenBox = true;
                Chapter1Manager.Instance.SetHomeTime(2);
                break;
            case 108:
                Chapter1Manager.Instance.tiedCurtains = true;
                Chapter1Manager.Instance.SetHomeTime(3);
                Chapter1Manager.Instance.isPherka4 = true;
                int monologueId = 21002 + Chapter1Manager.Instance.completeIndex;
                Chapter1Manager.Instance.completeIndex++;
                SetDialogueFinishedCallback(() => StartMonologue(monologueId), false);
                break;
            case 200:
                Chapter2Manager.Instance.SetRestTime(false);
                break;
            case 201:
                Chapter2Manager.Instance.SetRestTime(true);
                break;
            case 202:
                Chapter2Manager.Instance.SetRestTime(false);
                break;
        }
    }
    private IEnumerator TalkNextFrame(ObjectData objData)
    {
        yield return null;
        // 선택 당시 이전 문장의 글자 출력이 진행 중이라면 끝날 때까지 기다림
        yield return new WaitUntil(() => !TextAnim.Instance.isAnim);
        if (objData == null)
            yield break;
        Talk(objData);
    }
    private void EndDialogue(ObjectData objData)
    {
        int finishedDialogueId = lastDisplayedDialogueId;
        int finishedLineIndex = lastDisplayedLineIndex;
        lastDisplayedDialogueId = -1;
        lastDisplayedLineIndex = -1;
        if (!gameData.isTrigger && objData != null)
        {
            objData.AdvanceDialogue();
        }
        StopAllCoroutines();
        isProcessingDialogueLine = false;
        gameData.isAction = false;
        gameData.isTrigger = false;
        gameData.triggerObjectData = null;
        gameData.scanObject = null;
        currentDialogueObject = null;
        if (FadeManager.Instance != null)
        {
            FadeManager.Instance.fadeData.isFading = false;
        }
        currentLineIdx = 0;
        UIManager.Instance.HideChoices();
        UIManager.Instance.SetDialogueBoxActive(false);
        Debug.Log($"EndDialogue 실행 / 등록된 콜백: {onDialogueFinished?.Method.Name ?? "없음"}");
        Action callback = onDialogueFinished;
        onDialogueFinished = null;
        isProcessingDialogueLine = true;
        StartCoroutine(ProcessDialogueEnd(finishedDialogueId, finishedLineIndex, callback));
    }
    private IEnumerator ProcessDialogueEnd(int dialogueId, int lineIndex, Action callback)
    {
        // 대화창을 닫은 다음 프레임에 종료 이벤트 실행
        yield return null;

        if (dialogueId >= 0 && lineIndex >= 0 && DialogueEventManager.Instance != null)
        {
            yield return StartCoroutine(DialogueEventManager.Instance.ExecuteEvent(dialogueId, lineIndex, DialogueEventTiming.EndDialogue));
        }

        isProcessingDialogueLine = false;

        // 종료 이벤트가 완료된 뒤 기존 종료 콜백 실행
        if (callback != null)
            yield return StartCoroutine(InvokeDialogueCallbackNextFrame(callback));
    }

    private IEnumerator InvokeDialogueCallbackNextFrame(Action callback)
    {
        yield return null;
        callback?.Invoke();
    }
    private void ShowMonologueLine()
    {
        if (isProcessingDialogueLine)
            return;
        StartCoroutine(ProcessMonologueLine());
    }
    private IEnumerator ProcessMonologueLine()
    {
        isProcessingDialogueLine = true;
        int lineIndex = currentMonologueLineIdx;
        DialogueLine? line = DialogueManager.Instance.GetLine(
            currentMonologueId,
            lineIndex
        );
        if (!line.HasValue)
        {
            isProcessingDialogueLine = false;
            FinishMonologue();
            yield break;
        }
        if (DialogueEventManager.Instance != null)
        {
            yield return StartCoroutine(
                DialogueEventManager.Instance.ExecuteEvent(
                    currentMonologueId,
                    lineIndex,
                    DialogueEventTiming.BeforeLine
                )
            );
        }
        if (!isMonologue)
        {
            isProcessingDialogueLine = false;
            yield break;
        }
        DialogueLine currentLine = line.Value;
        string nameData = currentLine.defaultname;
        UIManager.Instance.UpdateMonologueUI(
            nameData,
            currentLine
        );
        UIManager.Instance.SetDialogueBoxActive(true);
        lastDisplayedDialogueId = currentMonologueId;
        lastDisplayedLineIndex = lineIndex;

        currentMonologueLineIdx = currentLine.nextLineIdx;
        isProcessingDialogueLine = false;
    }
    public void StartMonologue(int dialogueId, Action onFinished)
    {
        if (isMonologue)
            return;
        isMonologue = true;
        onMonologueFinished = onFinished;
        currentMonologueId = dialogueId;
        currentMonologueLineIdx = 0;
        gameData.isAction = true;
        ShowMonologueLine();
    }
    public void StartMonologue(int dialogueId)
    {
        StartMonologue(dialogueId, null);
    }
    public void NextMonologueLine()
    {
        if (!isMonologue)
            return;
        ShowMonologueLine();
    }
    private void FinishMonologue()
    {
        int finishedDialogueId = lastDisplayedDialogueId;
        int finishedLineIndex = lastDisplayedLineIndex;
        lastDisplayedDialogueId = -1;
        lastDisplayedLineIndex = -1;
        isMonologue = false;
        isProcessingDialogueLine = false;
        currentMonologueId = -1;
        currentMonologueLineIdx = 0;
        gameData.isAction = false;
        gameData.isTrigger = false;
        UIManager.Instance.HideChoices();
        UIManager.Instance.SetDialogueBoxActive(false);
        Action callback = onMonologueFinished;
        onMonologueFinished = null;
        isProcessingDialogueLine = true;
        StartCoroutine(ProcessDialogueEnd(finishedDialogueId, finishedLineIndex, callback));
    }
    public void SetDialogueFinishedCallback(Action callback, bool overwrite = true)
    {
        if (!overwrite && onDialogueFinished != null)
            return;
        onDialogueFinished = callback;
    }
    public Vector3 GetMainStreetMap()
    {
        return mainStreetMap;
    }
    public Vector3 GetChapter1Map()
    {
        return chapter1Map;
    }
    public Vector3 GetChapter2Map()
    {
        return chapter2Map;
    }
    public Vector3 GetChapter3Map()
    {
        return chapter3Map;
    }
    public void Quit()
    {
        Application.Quit();
    }
}
